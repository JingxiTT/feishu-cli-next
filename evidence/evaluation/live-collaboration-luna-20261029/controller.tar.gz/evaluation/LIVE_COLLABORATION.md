# Live collaboration evaluation

[tasks.live-collaboration.json](tasks.live-collaboration.json) adds seven
permission-bounded workflows to the [real Feishu pipeline](PIPELINE.md).
The controller is [live_collaboration.py](live_collaboration.py); it shares
account binding, private ACL checks and mutation recovery with the business
fixtures. No synthetic API backend or held-out task is used.

| Case | Independent outcome verification |
|---|---|
| `collaboration-im-read` | Read designated message IDs in batches of at most 50. Verify complete IDs, chronological order, message types, edit markers and an exact raw-body Unicode digest; preserve message state. |
| `collaboration-group-read` | Read every page of a bounded group-message window. Verify the same complete-history report and unchanged native source snapshot. |
| `collaboration-document-create` | Create a new private TEST document from supplied complete XML. Verify title, native heading, bold hyperlink, Unicode, leading-zero codes and 3-by-2 table. |
| `collaboration-image-upload` | Append two different PNGs with identical basenames to a private document. Verify native image order, display dimensions, exact downloaded bytes and preservation of every prior block. |
| `collaboration-file-upload` | Append multiline Unicode CSV and binary bytes containing NULs as native document attachments. Verify filenames, view/file parent-child links, order, downloaded bytes and prior blocks. |
| `collaboration-mermaid-create` | Append a native whiteboard from supplied Mermaid. Verify exact stored source, three participants, four message connectors and a conditional fragment. |
| `collaboration-drawing-create` | Append a native whiteboard from supplied SVG. Verify editable circle/rounded rectangle and text, geometry, colors, labels and connector endpoints; inspect the diamond's vector fallback. |

Document attachments satisfy the upload cases. These cases do not claim Drive
folder-placement verification, IM resource upload, or delivery to anyone.
The drawing checks native nodes and their geometry; it is not a subjective
visual-design score. Feishu converts SVG into nodes instead of retaining an
original SVG syntax block. Mermaid input has no terminal newline because the
server removes it during import. File attachments have native view containers;
those containers and their child relationships are checked rather than ignored.

## Private fixtures and scope

Read [all testing authorization boundaries](../docs/testing.md#authorization-boundaries-for-all-testing).
Existing user scopes only: no login/consent flow, group creation, message
seeding, delivery, invitations or permission changes. All new top-level
resources are named `[TEST]` and use current-account private ACLs.

The five document cases use the same owner-only `private_parent` configuration
as [the business driver](LIVE_BUSINESS.md). A creation result is eligible for
cleanup only after independent account/owner/ACL verification, exact unique
run title and native creation time. `creation.json` is the required immediate
creation journal; a valid returned answer is a recovery fallback. Unknown
creation outcomes remain blocked for reconciliation, not automatically retried.
The document itself is checked; destination-folder placement is not scored.

IM cases require an **explicitly designated existing private TEST fixture**.
The permission list does not authorize creating a group, and the evaluation
must not send messages to seed one. Without the private configuration below,
they block before any identity/chat/message API is called and no model is billed.
Do not include blocked IM cases in a success denominator.

Add the applicable entries to the protected resources file (values are private):

```json
{
  "im_messages": {
    "chat_id": "<designated TEST chat>",
    "message_ids": ["<designated test message>"],
    "read_authorized_by_user": true,
    "label": "[TEST]",
    "account_binding": "<independent account binding digest>"
  },
  "im_group": {
    "chat_id": "<designated TEST group>",
    "start_time": 1700000000,
    "end_time": 1700003600,
    "read_authorized_by_user": true,
    "label": "[TEST]",
    "account_binding": "<independent account binding digest>"
  }
}
```

The controller checks the actual TEST chat name, owner, complete untruncated
membership and tenant before reading message content. Under the private-fixture
boundary the sole member is the current account, with no bots or other users.
It never discovers or reads unrelated chats. A normal business group is not a
private fixture. The two IM cases can use the same designated TEST group:
individual message retrieval and paginated history are different workflows.

IM reads do not create remote resources; their cleanup verifies the journal
contains no mutation. New Docs and attachments/boards are cleaned by their
registered document IDs, then the test folders. Unknown outcomes retain all
recovery state. Never replay an uncertain mutation.

## Running

Use three repeats per arm with the same frozen production binaries, guidance,
model, reasoning and budget. Point `live_manifests.paired` at this manifest and
`live.driver` at `live_collaboration.py` with the same `--cli`, `--binding` and
`--resources` arguments as the business driver. Use a fresh experiment/output
directory and freeze the evaluator before billing models.

`--section collaboration` selects only the five document cases (30 planned
attempts at three repeats). `--section im` selects the two conditional IM cases
(12 planned attempts). Selecting both schedules 42 attempts, and IM preflight
blocks execution if its prerequisites are missing. A blocked case is not a pass.
Report its reason separately; do not replace it with mock messages or broaden
permissions. Keep this workflow mix separate from prior comparison aggregates.

Run `make evaluation-test` for offline verifier tests. Calibration against real
Feishu is controller validation, not task success or token-efficiency evidence.
Record all calibration failures and model attempts, including their full costs.
