from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parent;repo=root.parents[1];sys.path.insert(0,str(repo/'evaluation'))
from live_domains import complex
from live_domains.session import exact
batch=json.loads(next((root/'run-corrected').rglob('batch-01.json')).read_text());runs=batch['runs'];states=sorted((root/'run-corrected').rglob('verifier.json'),key=lambda p:p.stat().st_mtime_ns)
assert len(states)>=len(runs)
rows=[]
for run,marker in zip(runs,states):
 config=json.loads(marker.read_text());assert config['live_task']['id']==run['task_id']
 row={k:run[k] for k in ['task_id','arm','trial']};row.update(raw_recorded_success=run['success'],native_task_success=run['success'],basis='Frozen live verifier')
 if run['task_id']=='business-document-closeout':
  state=marker.parent;data=json.loads((state/'docs/common-state.json').read_text());workspace=state/'workspace';before=data['before'];_,audit,_=complex.closeout_result(before)
  try:
   answer=json.loads((workspace/'answer.json').read_text());path=(workspace/answer['path']).resolve();assert path.is_relative_to(workspace.resolve())
   report=json.loads(path.read_text());report_ok=exact(report,audit)
  except (OSError,ValueError,KeyError,TypeError,AssertionError):report_ok=False;report={}
  row['report_exact']=report_ok
  if not report_ok:
   selected=set(report.get('block_ids',[]));zero=0
   for block in before:
    if block['block_id'] in selected:
     text=__import__('live_domains.docs',fromlist=['text']).text(block)
     if 'Amount=0 |' in text:zero+=1
   row.update(native_task_success=False,basis='Submitted report compared against independent native before snapshot',expected_record_count=audit['record_count'],submitted_record_count=report.get('record_count'),incorrect_zero_amount_selections=zero)
  else:
   snapshots=[];items=[];files=[]
   for path in sorted((state/'docs').glob('command-*.json'),key=lambda p:p.stat().st_mtime_ns):
    if path.stat().st_mtime_ns<=marker.stat().st_mtime_ns:continue
    try:response=json.loads(json.loads(path.read_text())['stdout'])['data'];chunk=response.get('items')
    except (ValueError,KeyError,TypeError):continue
    if chunk and all(isinstance(v,dict) and 'block_id' in v for v in chunk):
     items+=chunk;files.append(path)
     if response.get('has_more') is False:snapshots.append((items,files));items=[];files=[]
   assert snapshots,'No independent post-model native content readback retained'
   after,proof=snapshots[-1]
   success=complex.closeout_preserved(before,after)
   row.update(native_task_success=success,basis='Complete independently recorded post-model native readback; coalesce only adjacent text runs with identical metadata',native_blocks=len(after),readback_pages=len(proof),readback_sha256=[hashlib.sha256(p.read_bytes()).hexdigest() for p in proof],raw_verifier_false_rejection=success and not run['success'])
   assert not run['success'] or success,'Correction must retain every original verified pass'
 rows.append(row)
record={'measurement':'Reassessment of recorded real Feishu native readback; no new model calls or tenant actions','raw_records_unchanged':True,'rule':'Native run segmentation may differ only within selected edited paragraphs; text, per-run metadata/styles/links, block IDs and all unrelated native blocks/root order must still match exactly. Adjacent text runs merge only when every field except content is identical. Report types and all selection predicates remain exact.','corrective_source_sha256':hashlib.sha256((repo/'evaluation/live_domains/complex.py').read_bytes()).hexdigest(),'runs':rows}
(root/'readback-reassessment.json').write_text(json.dumps(record,indent=2)+'\n')
print('Reassessed',len(rows),'recorded trials; native successes',sum(v['native_task_success'] for v in rows),'raw accepted',sum(v['raw_recorded_success'] for v in rows),'false rejections',sum(v.get('raw_verifier_false_rejection',False) for v in rows))
