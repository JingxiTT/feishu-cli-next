#!/usr/bin/env python3
"""Local provider selection for the unchanged native Codex evaluation adapter."""
import argparse
import json
from pathlib import Path
import sys
import tomllib

parser = argparse.ArgumentParser()
parser.add_argument('--source', type=Path, required=True)
parser.add_argument('--codex', type=Path, required=True)
parser.add_argument('--auth-home', type=Path, required=True)
parser.add_argument('--provider-config', type=Path, required=True)
args = parser.parse_args()
sys.path.insert(0, str(args.source / 'evaluation'))
import codex_runner

config = tomllib.loads(args.provider_config.read_text())
provider_id = config['model_provider']
settings = config['model_providers'][provider_id]
assert provider_id.isalnum()
assert set(settings) <= {'name', 'base_url', 'wire_api', 'env_key', 'supports_websockets'}
assert settings['wire_api'] == 'responses'
settings = {key: value for key, value in settings.items() if key != 'env_key'}
settings['requires_openai_auth'] = True
original_configuration = codex_runner.configuration

def configuration(*positional, **keywords):
    return original_configuration(*positional, **keywords) + [
        'model_provider=' + json.dumps(provider_id),
        *['model_providers.' + provider_id + '.' + key + '=' + json.dumps(value)
          for key, value in settings.items()]]

codex_runner.configuration = configuration
response, code = codex_runner.run(json.load(sys.stdin), args.codex, args.auth_home,
                                  'codex-cli 0.165.0')
print(json.dumps(response))
sys.exit(code)
