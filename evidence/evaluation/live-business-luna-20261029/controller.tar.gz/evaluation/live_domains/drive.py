# Copyright (c) 2026 Lark Technologies Pte. Ltd.
# SPDX-License-Identifier: MIT

"""Exact-byte file download and upload/download round trips."""
import hashlib
import uuid

from live_domains.session import require

PAYLOAD = bytes(range(256)) * 16 + 'Résumé 你好 😀\n001\n'.encode()


def download(s, token):
    name = 'download-' + uuid.uuid4().hex + '.bin'
    s.call(['drive', '+download', '--file-token', token, '--output', name, '--as', 'user'])
    return (s.state / name).read_bytes()


def setup(s):
    folder = s.folder()
    source = s.state / (s.data['tag'] + '-guard.bin')
    source.write_bytes(PAYLOAD)
    source.chmod(0o600)
    data = s.mutation('seed-file', lambda: s.call(['drive', '+upload', '--folder-token', folder,
        '--file', source.name, '--as', 'user']), ('file', 'file_token'))
    s.data['seed_token'] = data['file_token']
    s.save()
    require(download(s, data['file_token']) == PAYLOAD, 'file_seed_mismatch')
    if s.request['task']['id'] == 'common-drive-read':
        return ('Download file ' + data['file_token'] + ' and report its SHA-256 and byte count. '
                'Do not replace, upload or delete any remote file.')
    name = s.data['tag'] + '.bin'
    (s.workspace / name).write_bytes(PAYLOAD + b'round-trip\x00\xff')
    s.data['source_name'] = name
    s.save()
    return ('Upload local file ' + name + ' to folder ' + folder + ', preserving its filename and '
            'exact bytes. Download the uploaded file to a different local path and confirm the '
            'round trip. Return file_token and the relative downloaded path. Upload the requested '
            'file and leave the existing guard file unchanged.')


def verify(s, answer):
    if download(s, s.data['seed_token']) != PAYLOAD:
        return False
    if s.request['task']['id'] == 'common-drive-read':
        return answer == {'sha256': hashlib.sha256(PAYLOAD).hexdigest(), 'bytes': len(PAYLOAD)}
    token = answer.get('file_token')
    s.remember_file(token)
    expected = PAYLOAD + b'round-trip\x00\xff'
    return (download(s, token) == expected
            and s.artifact(answer.get('path')).read_bytes() == expected
            and s.artifact(answer['path']) != s.workspace / s.data['source_name'])


def cleanup(s):
    s.cleanup_drive()
