# Live business workflows

[tasks.live-business.json](tasks.live-business.json) contains five development
workflows. They seed fictitious business data into **real Feishu resources**;
there is no API simulator, mock endpoint or canned task result. Each attempt
gets fresh resources and independently reads the resulting native state. Setup,
verification and cleanup are controller work, not agent success measurements.

| Workflow | Work and independently checked outcome |
|---|---|
| `business-cross-source-report` | Read typed spreadsheet cells and all 205 Base records, aggregate filtered totals, write a JSON report and append one native document paragraph; preserve every source cell/record and all previous native blocks/styles/links. |
| `business-document-edit` | Replace a release status while preserving its bold link, native block IDs, Unicode and all unrelated content. |
| `business-sheet-reconcile` | Set one numeric value to zero and one text value to empty, preserving leading-zero codes, booleans, formulas, styles and guard cells. Formula results may recalculate. |
| `business-base-reconcile` | Append two intake records containing zero, false, null and Unicode. Read every page to establish that all 205 original rows remain unchanged. |
| `business-file-handoff` | Upload a binary handoff file, download it separately and verify both copies against trusted bytes; independently check that the existing guard file is unchanged. |

The workflows require the existing granular Docs, Sheets, Base, My Space
metadata, upload, download, folder-create and document-delete permissions.
They do not create or update Tasks, request calendar/mail scopes, enumerate
unrelated Drive folders, deliver messages or add collaborators. Missing scopes
block a workflow rather than triggering login or being counted as a failure of
the model. Never expand authorization automatically to make a test run.

All top-level resource names and uploaded filenames start with `[TEST]`.
The Base table name starts with `TEST`, because Feishu forbids square brackets
in table names; its containing Base and folder retain `[TEST]`. Content is
fictitious and includes deliberate leading-zero, empty-string, zero, false,
null, Unicode, rich-text and pagination cases.

## Private setup

Read the [testing authorization boundaries](../docs/testing.md#authorization-boundaries-for-all-testing).
The current user must authorize creating these test resources. Provision a fresh
`[TEST]` parent with that identity, record its token immediately, and verify its
metadata owner, closed link sharing and sole current-account membership before
seeding content. The driver repeats those checks before creating children and
checks each child's ACL before writing task data. Do not use an unrelated or
shared production folder, or broaden permissions to make a fixture work.

Keep an owner-only resources file outside version control:

```json
{
  "private_parent": {
    "folder_token": "<run-owned TEST parent>",
    "creation_authorized_by_user": true,
    "label": "[TEST]",
    "account_binding": "<digest from the independent account binding file>"
  }
}
```

The authorization flag records the user's actual authorization; it is not proof
of identity or ACL. The driver independently verifies both. The account binding
uses the Contact driver's format described in [PIPELINE.md](PIPELINE.md).
Credentials stay in the existing protected CLI configuration and data directories.

Configure the existing pipeline with `suites: ["paired"]`,
`workloads: ["workflow"]`, and `live_manifests.paired` pointing to the absolute
business manifest path. Its `live.driver` is:

```json
[
  "/absolute/python3", "/absolute/source/evaluation/live_workspace.py",
  "--cli", "/absolute/frozen-official-cli",
  "--binding", "/absolute/private/account-binding.json",
  "--resources", "/absolute/private/resources.json"
]
```

The same frozen controller is used for both arms. Keep the model, reasoning,
tool access, budget and guidance delivery identical. Use at least two repeats.
Public schemas and user goals are shipped; account IDs, remote tokens, binding
proofs, controller state and model artifacts stay in protected local outputs.

## Verification and recovery

The controller reads native blocks, raw/formula cells and complete Base pages.
It compares task outcomes, exact JSON types and preservation conditions, rather
than trusting the model's answer. Unknown or nonadvancing pagination fails
verification. Source changes cannot be hidden by an otherwise correct summary.

Every controller mutation is journaled **before** dispatch, with returned IDs
persisted immediately. Uncertain outcomes leave `pending` set and block cleanup
and replay. Reconcile those exact operations first; never clear a marker merely
to rerun a failed setup. Validation or explicit authorization rejections can be
recorded as confirmed unapplied after inspecting their protected diagnostics.

Cleanup uses the exact run-owned IDs journaled by creation or validated output,
verifies owner/ACL, and requires the delete command's confirmed server outcome.
It does not require broad Drive-list permissions. The fresh run-owned folder is
deleted after its known children; the controller never traverses unrelated
folders. Unknown model-created files outside that folder cannot be claimed
cleaned. Keep any unresolved state and report the limitation.

Remove the run's parent only after every attempt and calibration fixture is
confirmed cleaned. Do not publish raw outputs or real tenant identifiers.

Offline tests in `tests/next_evaluation/test_live_business.py` check preservation,
type distinctions, pagination, private binding, file paths and mutation recovery.
Run `make evaluation-test` after changing the driver. These mocks are tooling
tests, not live task or token-efficiency evidence.
